#!/bin/bash
echo Lancement du programme AG41-Transshipment-Problem
java -jar AG41-resolution.jar
echo Programme Terminé
exit 0
