/**
 * Created by delan on 22/04/16.
 */
public enum Type
{
    FOURNISSEUR,
    PLATEFORME,
    CLIENT
}
